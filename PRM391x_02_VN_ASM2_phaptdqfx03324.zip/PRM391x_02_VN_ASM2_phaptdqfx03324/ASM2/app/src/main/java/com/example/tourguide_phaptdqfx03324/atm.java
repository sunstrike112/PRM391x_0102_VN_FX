package com.example.tourguide_phaptdqfx03324;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


/**
 * Here is the fragment for the ATM
 * This class generated automatically by the IDE generator
 * Every fragment nearly same, just change some variable
 */
public class atm extends Fragment {
    ListView listView;

    String mATM[] = {"ATM Hoàn Kiếm",
            "ATM Đinh Tiên Hoàng",
            "ATM Hội sở",
            "ATM Nam Hà Nội",
            "ATM Hai Bà Trưng",
            "ATM Lê Ngọc Hân",
            "ATM Thăng Long",
            "ATM Phạm Hùng",
            "ATM Khâm Thiên"};
    String mAddress[] = {"17 phố Lý Thường Kiệt, Phường Phan Chu Trinh, Quận Hoàn Kiếm, Hà Nội",
            "7 Đinh Tiên Hoàng, Quận Hoàn Kiếm, Hà Nội",
            "57 Lý Thường Kiệt, Quận Hoàn Kiếm, Hà Nội",
            "236 Lê Thanh Nghị, Quận Hai Bà Trưng, Hà Nội",
            "300-302 Trần Khát Chân, Quận Hai Bà Trưng, Hà Nội",
            "44 Lê Ngọc Hân, Quận Hai Bà Trưng, Hà Nội",
            "129-131 Hoàng Quốc Việt, Quận Cầu Giấy, Hà Nội",
            "Tòa nhà FPT Phạm Hùng, Quận Cầu Giấy, Hà Nội",
            "158 Khâm Thiên, Quận Đống Đa, Hà Nội"};

    public atm() {
        // Required empty public constructor
    }

    //Here's where the fragment will showed
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        //Adding a view
        View view = inflater.inflate(R.layout.fragment_layout, container, false);
        listView = view.findViewById(R.id.hotelList);
        atm.listAdapter adapter = new atm.listAdapter(getContext(), mATM, mAddress);
        listView.setAdapter(adapter);
        return view;
    }

    //Here's where I make the custom view for the list view
    class listAdapter extends ArrayAdapter<String> {
        Context context;
        String rAtm[];
        String rAddress[];


        listAdapter(Context c, String title[], String address[]){
            super(c, R.layout.custom_list_view, R.id.judul_gede, title);
            this.context = c;
            this.rAtm = title;
            this.rAddress = address;
        }

        //Here's where I make the custom view for the list view
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View customRow =  layoutInflater.inflate(R.layout.custom_list_view, parent, false);
            TextView iAddress = customRow.findViewById(R.id.isi);
            TextView iTitle = customRow.findViewById(R.id.judul_gede);
            ImageView icon = (ImageView) customRow.findViewById(R.id.icon);

            iAddress.setText(rAddress[position]);
            iTitle.setText(rAtm[position]);
            icon.setImageResource(R.drawable.atm);

            return customRow;
        }
    }
}

