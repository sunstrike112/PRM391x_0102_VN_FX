package com.example.tourguide_phaptdqfx03324;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


/**
 * Here is the fragment for the Hospital
 * This class generated automatically by the IDE generator
 * Every fragment nearly same, just change some variable
 */
public class hospital extends Fragment {
    ListView listView;

    String mHospital[] = {"Bệnh viện Bạch Mai",
            "Bệnh Viện Hữu Nghị",
            "Bệnh Viện E, Hà Nội",
            "Viện Răng Hàm Mặt",
            "Bệnh Viện Tai Mũi Họng Trung Ương",
            "Bệnh Viện Mắt Trung Ương",
            "Viện Y Học Cổ Truyền Trung Ương",
            "Bệnh Viện Nội Tiết",
            "Bệnh Viện Việt Đức",
            "Bệnh Viện Nhi Trung Ương"
    };
    String mAddress[] = {"78 – Đường Giải Phóng – Phương Mai – Đống Đa – Hà Nội",
            "Số 1 – Trần Khánh Dư – Quận Hai Bà Trưng – Hà Nội",
            "89 – Trần Cung – Nghĩa Tân – Cầu Giấy – Hà Nội",
            "40B – Tràng Thi – Hoàn Kiếm – Hà Nội",
            "78 – Đường Giải Phóng – Quận Đống Đa – Hà Nội",
            "85 – Phố Bà Triệu – Quận Hai Bà Trưng – Hà Nội",
            "29 – Phố Nguyễn Bỉnh Khiêm – Quận Hai Bà Trưng – Hà Nội",
            "80 – Thái Thịnh II – Thịnh Quang – Đống Đa – Hà Nội",
            "8 – Phố Phủ Doãn – Quận Hoàn Kiếm – Hà Nội",
            "18/879 – Đường La Thành – Quận Đống Đa – Hà Nội"
    };

    public hospital() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){
        //Adding a view
        View view = inflater.inflate(R.layout.fragment_layout, container, false);
        listView = view.findViewById(R.id.hotelList);
        hospital.listAdapter adapter = new hospital.listAdapter(getContext(), mHospital, mAddress);
        listView.setAdapter(adapter);
        return view;
    }

    //Here's where I make the custom view for the list view
    class listAdapter extends ArrayAdapter<String> {
        Context context;
        String rHotel[];
        String rAddress[];


        listAdapter(Context c, String title[], String address[]){
            super(c, R.layout.custom_list_view, R.id.judul_gede, title);
            this.context = c;
            this.rHotel = title;
            this.rAddress = address;
        }

        //Here's where I make the custom view for the list view
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View customRow =  layoutInflater.inflate(R.layout.custom_list_view, parent, false);
            TextView iAddress = customRow.findViewById(R.id.isi);
            TextView iTitle = customRow.findViewById(R.id.judul_gede);
            ImageView icon = (ImageView) customRow.findViewById(R.id.icon);

            iAddress.setText(rAddress[position]);
            iTitle.setText(rHotel[position]);
            icon.setImageResource(R.drawable.hospital);

            return customRow;
        }
    }
}
