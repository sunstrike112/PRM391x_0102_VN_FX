- Android Studio version 4.1.2
- Cac buoc cai dat co the lam theo huong dan chi tiet sau : https://www.thegioididong.com/hoi-dap/cach-cai-file-apk-tren-android-1066923
Link video : https://www.youtube.com/watch?v=nOqrk8k9mJY
Link cai dat ung dung : https://deploygate.com/distributions/41cd8857fd419c08694780bef6780967d164266e